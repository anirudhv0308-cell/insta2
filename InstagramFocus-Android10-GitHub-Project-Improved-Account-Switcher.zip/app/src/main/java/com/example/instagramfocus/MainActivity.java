package com.example.instagramfocus;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(15,15,18), panel=Color.rgb(31,31,37), white=Color.WHITE, muted=Color.rgb(175,175,185);
    LinearLayout root;
    String account="Demo account";

    public void onCreate(Bundle b){
        super.onCreate(b);
        account = getSharedPreferences("focus_demo", MODE_PRIVATE).getString("active_account", "Demo account");
        makeChannel();
        askNotificationPermission();
        login();
    }
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(5),dp(5),dp(5),dp(5));if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    void base(){root=col();root.setBackgroundColor(bg);setContentView(root);}
    Button btn(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(white);b.setBackground(shape(Color.rgb(102,79,225),14));b.setOnClickListener(v->r.run());return b;}
    void login(){
        base();root.setGravity(Gravity.CENTER);
        LinearLayout box=col();box.setPadding(dp(22),dp(22),dp(22),dp(22));box.setBackground(shape(panel,22));
        TextView title=label("Instagram Focus",28,white,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView note=label("Stories and messages, without a feed",14,muted,false);note.setGravity(Gravity.CENTER);box.addView(note);
        EditText user=field("Demo username",false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(18);box.addView(user,p);
        EditText pass=field("Demo password — not sent anywhere",true);p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(8);box.addView(pass,p);
        TextView disclaimer=label("Prototype only. Do not enter your real Instagram password. This app does not connect to Instagram.",12,muted,false);disclaimer.setGravity(Gravity.CENTER);box.addView(disclaimer);
        p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(14);box.addView(btn("Continue in demo mode",()->{account=user.getText().toString().trim();if(account.isEmpty())account="Demo account";getSharedPreferences("focus_demo", MODE_PRIVATE).edit().putString("active_account", account).apply();home();}),p);
        TextView sw=label("Switch demo account",14,muted,false);sw.setGravity(Gravity.CENTER);sw.setOnClickListener(v->accounts());box.addView(sw,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout.LayoutParams outer=new LinearLayout.LayoutParams(-1,-2);outer.setMargins(dp(20),dp(10),dp(20),dp(10));root.addView(box,outer);
    }
    EditText field(String hint,boolean password){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(muted);e.setTextColor(white);e.setPadding(dp(12),0,dp(12),0);e.setBackground(shape(Color.rgb(48,48,55),12));e.setInputType(password?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);return e;}
    void header(String title,Runnable back){LinearLayout h=row();TextView b=label("‹",32,white,true);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->back.run());h.addView(b,new LinearLayout.LayoutParams(dp(42),dp(48)));h.addView(label(title,21,white,true),new LinearLayout.LayoutParams(0,dp(48),1));root.addView(h);}
    void home(){
        base();LinearLayout h=row();h.setPadding(dp(12),dp(6),dp(12),dp(6));h.addView(label("Instagram Focus",22,white,true),new LinearLayout.LayoutParams(0,dp(48),1));
        TextView sw=label("⇄",25,white,true);sw.setGravity(Gravity.CENTER);sw.setOnClickListener(v->accounts());h.addView(sw,new LinearLayout.LayoutParams(dp(48),dp(48)));root.addView(h);
        EditText search=field("Search people or interests",false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(46));sp.setMargins(dp(14),dp(5),dp(14),dp(10));root.addView(search,sp);
        search.setOnEditorActionListener((v,a,event)->{searchResults(search.getText().toString());return true;});
        ScrollView scroll=new ScrollView(this);LinearLayout content=col();content.setPadding(dp(14),0,dp(14),dp(12));
        content.addView(label("Stories",20,white,true));
        LinearLayout stories=row();
        String[] names={"＋ You","Maya","Alex","Sam","Jordan"};String[] icons={"＋","🌸","🎧","🏀","🎨"};
        for(int i=0;i<names.length;i++){final String n=names[i];LinearLayout item=col();item.setGravity(Gravity.CENTER);TextView circle=label(icons[i],23,white,true);circle.setGravity(Gravity.CENTER);circle.setBackground(shape(i==0?panel:Color.rgb(102,75,200),40));item.addView(circle,new LinearLayout.LayoutParams(dp(56),dp(56)));TextView nm=label(n,11,muted,false);nm.setGravity(Gravity.CENTER);item.addView(nm,new LinearLayout.LayoutParams(dp(62),dp(30)));item.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(n+" story").setMessage("Demo story preview only.").setPositiveButton("Close",null).show());stories.addView(item);}
        content.addView(stories);LinearLayout mh=row();mh.addView(label("Messages",20,white,true),new LinearLayout.LayoutParams(0,dp(50),1));TextView bell=label("🔔",20,white,false);bell.setGravity(Gravity.CENTER);bell.setOnClickListener(v->notifyDemo());mh.addView(bell,new LinearLayout.LayoutParams(dp(46),dp(46)));content.addView(mh);
        message(content,"Maya Chen","Are we still meeting later?","MC");message(content,"Alex Rivera","Sent you the playlist 🎧","AR");message(content,"Sam Patel","That photo looks great!","SP");message(content,"Jordan Lee","See you tomorrow.","JL");
        content.addView(label("Recommended searches",18,white,true));content.addView(label("People: Maya Chen • Alex Rivera • Sam Patel • Jordan Lee",13,muted,false));content.addView(label("Interests: photography • art • music • basketball",13,muted,false));
        scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setBackgroundColor(Color.rgb(24,24,29));navItem(nav,"Stories",()->home());navItem(nav,"Messages",()->messages());navItem(nav,"Search",()->searchResults(""));navItem(nav,"Account",()->accounts());root.addView(nav,new LinearLayout.LayoutParams(-1,dp(54)));
    }
    void navItem(LinearLayout nav,String name,Runnable r){TextView t=label(name,12,white,true);t.setGravity(Gravity.CENTER);t.setOnClickListener(v->r.run());nav.addView(t,new LinearLayout.LayoutParams(0,-1,1));}
    void message(LinearLayout parent,String name,String msg,String initials){LinearLayout item=row();item.setPadding(dp(4),dp(7),dp(4),dp(7));TextView av=label(initials,13,white,true);av.setGravity(Gravity.CENTER);av.setBackground(shape(Color.rgb(78,65,145),40));item.addView(av,new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout words=col();words.setPadding(dp(10),0,0,0);words.addView(label(name,15,white,true));words.addView(label(msg,13,muted,false));item.addView(words,new LinearLayout.LayoutParams(0,-2,1));item.setOnClickListener(v->conversation(name));parent.addView(item);View line=new View(this);line.setBackgroundColor(Color.rgb(50,50,57));parent.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
    void messages(){base();header("Messages",()->home());LinearLayout list=col();list.setPadding(dp(14),0,dp(14),0);message(list,"Maya Chen","Are we still meeting later?","MC");message(list,"Alex Rivera","Sent you the playlist 🎧","AR");message(list,"Sam Patel","That photo looks great!","SP");message(list,"Jordan Lee","See you tomorrow.","JL");root.addView(list);}
    void searchResults(String query){base();header("Search",()->home());EditText e=field("Search people or interests",false);e.setText(query);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(46));p.setMargins(dp(14),dp(8),dp(14),dp(12));root.addView(e,p);e.setOnEditorActionListener((v,a,event)->{searchResults(e.getText().toString());return true;});LinearLayout list=col();list.setPadding(dp(14),0,dp(14),0);list.addView(label("Recommended searches",19,white,true));String q=query==null?"":query.toLowerCase();String[][] people={{"Maya Chen","photography • art","MC"},{"Alex Rivera","music • playlists","AR"},{"Sam Patel","basketball • friends","SP"},{"Jordan Lee","design • drawing","JL"}};int count=0;for(String[] x:people)if(q.isEmpty()||x[0].toLowerCase().contains(q)||x[1].toLowerCase().contains(q)){message(list,x[0],x[1],x[2]);count++;}if(count==0)list.addView(label("No demo matches. Try Maya, Alex, photography, music, or art.",14,muted,false));root.addView(list);}
    void conversation(String name){base();header(name,()->messages());LinearLayout body=col();body.setPadding(dp(16),dp(12),dp(16),dp(12));body.addView(label("Local demo conversation. No message is sent to Instagram.",13,muted,false));body.addView(label(name+": Hey! This is a sample message.",16,white,false));EditText msg=field("Write a demo message",false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(18);body.addView(msg,p);body.addView(btn("Send locally",()->{msg.setText("");Toast.makeText(this,"Demo only — not sent",Toast.LENGTH_SHORT).show();}));root.addView(body);}
    void accounts(){
        final AlertDialog dialog = new AlertDialog.Builder(this).create();
        LinearLayout sheet = col();
        sheet.setPadding(dp(18), dp(16), dp(18), dp(14));
        sheet.setBackgroundColor(Color.rgb(27,27,32));

        LinearLayout heading = row();
        TextView title = label("Switch accounts", 21, white, true);
        heading.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView close = label("✕", 18, muted, true);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        heading.addView(close, new LinearLayout.LayoutParams(dp(38), dp(42)));
        sheet.addView(heading);

        TextView subtitle = label("Choose which demo profile to use", 13, muted, false);
        sheet.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(30)));

        accountRow(sheet, account, account.equals("Demo account 2") ? "@demo_two" : "@" + account.toLowerCase().replace(" ", "_"),
            account.equals("Demo account 2") ? "D2" : initials(account), true, () -> {
                dialog.dismiss();
                home();
            });

        String otherName = account.equals("Demo account 2") ? "Demo account" : "Demo account 2";
        String otherHandle = account.equals("Demo account 2") ? "@demo" : "@demo_two";
        accountRow(sheet, otherName, otherHandle, initials(otherName), false, () -> {
            account = otherName;
            getSharedPreferences("focus_demo", MODE_PRIVATE).edit().putString("active_account", account).apply();
            dialog.dismiss();
            home();
            Toast.makeText(this, "Switched to " + account, Toast.LENGTH_SHORT).show();
        });

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(58,58,65));
        LinearLayout.LayoutParams divp = new LinearLayout.LayoutParams(-1, dp(1));
        divp.setMargins(0, dp(8), 0, dp(8));
        sheet.addView(divider, divp);

        actionRow(sheet, "＋", "Add demo account", "Create another local demo profile", () -> {
            dialog.dismiss();
            login();
        });
        actionRow(sheet, "⚙", "Account settings", "Prototype settings are not connected", () -> {
            dialog.dismiss();
            new AlertDialog.Builder(this).setTitle("Account settings")
                .setMessage("This prototype stores demo account choices locally. Instagram login, syncing, and real account data are not connected.")
                .setPositiveButton("Got it", null).show();
        });
        actionRow(sheet, "↪", "Log out", "Return to the demo login screen", () -> {
            getSharedPreferences("focus_demo", MODE_PRIVATE).edit().remove("active_account").apply();
            dialog.dismiss();
            login();
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(sheet);
        dialog.setView(scroll);
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(shape(Color.rgb(27,27,32), 22));
            dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92), -2);
        }
    }

    String initials(String name) {
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
        return (parts[0].substring(0,1) + parts[parts.length-1].substring(0,1)).toUpperCase();
    }

    void accountRow(LinearLayout parent, String name, String handle, String initials, boolean active, Runnable click) {
        LinearLayout item = row();
        item.setPadding(dp(5), dp(8), dp(5), dp(8));
        TextView avatar = label(initials, 14, white, true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(shape(active ? Color.rgb(105,78,220) : Color.rgb(75,75,86), 40));
        item.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout details = col();
        details.setPadding(dp(11), 0, dp(4), 0);
        details.addView(label(name, 15, white, true));
        details.addView(label(handle, 12, muted, false));
        item.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        if (active) {
            TextView check = label("✓", 21, Color.rgb(145,126,255), true);
            check.setGravity(Gravity.CENTER);
            item.addView(check, new LinearLayout.LayoutParams(dp(32), dp(42)));
        }
        item.setBackground(shape(Color.rgb(38,38,45), 14));
        item.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(6);
        parent.addView(item, p);
    }

    void actionRow(LinearLayout parent, String icon, String title, String detail, Runnable click) {
        LinearLayout item = row();
        item.setPadding(dp(5), dp(8), dp(5), dp(8));
        TextView symbol = label(icon, 21, white, true);
        symbol.setGravity(Gravity.CENTER);
        item.addView(symbol, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout words = col();
        words.setPadding(dp(8), 0, 0, 0);
        words.addView(label(title, 15, white, true));
        words.addView(label(detail, 12, muted, false));
        item.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        item.setOnClickListener(v -> click.run());
        parent.addView(item, new LinearLayout.LayoutParams(-1, -2));
    }
    void makeChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("focus_demo","Focus demo notifications",NotificationManager.IMPORTANCE_DEFAULT);c.setDescription("Local sample notifications");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    void askNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},5);}
    void notifyDemo(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"Allow notifications in Settings first.",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0)|PendingIntent.FLAG_UPDATE_CURRENT);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"focus_demo"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Instagram Focus").setContentText("This is a local demo notification.").setContentIntent(pi).setAutoCancel(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1,b.build());Toast.makeText(this,"Demo notification sent",Toast.LENGTH_SHORT).show();}
}
