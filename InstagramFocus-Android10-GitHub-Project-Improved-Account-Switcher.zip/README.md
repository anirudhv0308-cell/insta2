# Instagram Focus — Android 10 compatible prototype

Native Android Java project with `minSdk 23`, so Android 10 is supported in principle. The project uses compile SDK 35 and targets SDK 32. GitHub Actions builds the APK.

Features: demo login, Stories, Messages, search with recommended demo people/interests, account switching, and local demo notifications. No feed, Reels, or Explore.

IMPORTANT: This is a visual/local prototype only. It does not connect to Instagram. Do not enter your real Instagram credentials. Demo messages and notifications are local samples, not real Instagram activity.

To use: upload the contents of this ZIP to the root of a GitHub repository (extract the ZIP on GitHub or upload the files individually), then open Actions and run “Build Instagram Focus APK”. Download the `Instagram-Focus-Android10-APK` artifact.
