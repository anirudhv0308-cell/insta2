# Instagram Focus — Instagram-inspired Android prototype

This project is a focus-first launcher-style interface for Android. It uses Instagram's own website for supported account functions and adds a custom home screen intended to feel familiar to Instagram users.

## Current UI
- Instagram-inspired header and bottom navigation
- Horizontal Stories-style avatar row
- Direct links to Messages, Stories, and username-based Profiles
- A dedicated profile search screen
- Optional Android overlay reminder for the official Instagram app

## Build
This project uses Android Gradle Plugin 8.7.3 and compile SDK 35. Open the project folder in Android Studio or use the existing GitHub Actions workflow. If your workflow expects `InstagramFocus-Android-Project.zip`, upload this archive under that exact filename so the workflow can find it.

## Important limitations
- This is an original prototype inspired by Instagram's general layout, not a pixel-perfect reproduction or an official Instagram app.
- Instagram web may limit login, messaging, Stories, or other features inside Android WebView. If a feature does not work, that is a platform limitation rather than a guarantee that the prototype can fix it.
- Hiding links inside a web page is best-effort only and can break when Instagram changes its website. It is not a security boundary.
- The overlay reminder requires Android permissions and may behave differently across Android versions and OPPO/ColorOS battery-management settings. It is a reminder, not an unbypassable blocker.
- No private Instagram APIs, password collection, or credential scraping are used.


## Dark mode update
The custom native screens now use a black background, dark charcoal surfaces and dividers, white primary text, muted gray secondary text, and Instagram-style blue actions. The embedded Instagram website controls its own theme and may follow its own login/account/browser settings, so its appearance is not guaranteed to match the native screens exactly.

## Account shortcut button
A small circular account button appears beside the Instagram-style wordmark. It lets you save username shortcuts, open a saved profile, remove shortcuts, and go to Instagram's own login page to add/sign in to another account. For security, the app never stores passwords. Actual authenticated-account switching depends on Instagram's website/session support inside WebView; the shortcut list cannot independently change Instagram's logged-in session.
