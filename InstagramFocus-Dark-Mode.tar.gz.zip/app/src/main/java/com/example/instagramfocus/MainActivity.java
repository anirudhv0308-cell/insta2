package com.example.instagramfocus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String INBOX = "https://www.instagram.com/direct/inbox/";
    private static final int BLACK = Color.rgb(250,250,250), MUTED = Color.rgb(168,168,168), LINE = Color.rgb(38,38,38), WHITE = Color.rgb(0,0,0), SURFACE = Color.rgb(18,18,18), INPUT = Color.rgb(38,38,38);
    private LinearLayout root, content, bottomNav;
    private WebView webView;
    private EditText profileSearch;
    private TextView pageTitle;
    private SharedPreferences accountPrefs;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private GradientDrawable shape(int color, int strokeColor, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (stroke > 0) d.setStroke(dp(stroke), strokeColor); return d;
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void divider(LinearLayout parent) { View v = new View(this); v.setBackgroundColor(LINE); parent.addView(v,new LinearLayout.LayoutParams(-1,dp(1))); }

    @Override public void onCreate(Bundle state) { super.onCreate(state); accountPrefs = getSharedPreferences("saved_accounts", MODE_PRIVATE); getWindow().setStatusBarColor(WHITE); getWindow().setNavigationBarColor(WHITE); getWindow().getDecorView().setSystemUiVisibility(0); buildUI(); showHome(); }

    private void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(WHITE);
        LinearLayout header = row(); header.setPadding(dp(16),dp(6),dp(14),dp(6));
        TextView logo = text("Instagram",29,BLACK); logo.setTypeface(Typeface.create("cursive",Typeface.BOLD_ITALIC)); header.addView(logo,new LinearLayout.LayoutParams(0,dp(44),1));
        TextView accounts = icon("◉",23); accounts.setContentDescription("Switch accounts"); accounts.setBackground(shape(SURFACE,LINE,1,50)); LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(dp(38),dp(38)); accountLp.setMargins(0,0,dp(8),0); header.addView(accounts,accountLp); accounts.setOnClickListener(v -> showAccounts());
        TextView settings = icon("⚙",23); settings.setContentDescription("Settings"); settings.setPadding(dp(8),0,dp(2),0); settings.setOnClickListener(v -> showSettings()); header.addView(settings);
        root.addView(header); divider(root);

        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setBackgroundColor(WHITE); root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        webView = new WebView(this); webView.setBackgroundColor(WHITE); webView.getSettings().setJavaScriptEnabled(true); webView.getSettings().setDomStorageEnabled(true); webView.getSettings().setLoadsImagesAutomatically(true); webView.getSettings().setSupportMultipleWindows(false); webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true); webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl(); String host=uri.getHost()==null?"":uri.getHost().toLowerCase();
                if (host.equals("instagram.com") || host.endsWith(".instagram.com")) { String path=uri.getPath()==null?"/":uri.getPath(); if(path.equals("/")){view.loadUrl(INBOX);return true;} return false; }
                new AlertDialog.Builder(MainActivity.this).setTitle("Open external link?").setMessage("This link leaves Instagram Focus. Open it in your browser?").setNegativeButton("Cancel",null).setPositiveButton("Open",(d,w)->{try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}}).show(); return true;
            }
            @Override public void onPageFinished(WebView view,String url) { super.onPageFinished(view,url); String js="(function(){try{document.querySelectorAll('a[href]').forEach(function(a){var h=(a.getAttribute('href')||'').toLowerCase();if(h.indexOf('/reels')===0||h.indexOf('/explore')===0||h==='/'){a.style.display='none';}});if(location.pathname==='/'){location.replace('/direct/inbox/');}}catch(e){}})();"; view.evaluateJavascript(js,null); }
        });
        bottomNav = row(); bottomNav.setGravity(Gravity.CENTER); bottomNav.setPadding(dp(8),dp(5),dp(8),dp(5)); bottomNav.setBackgroundColor(WHITE);
        addNavItem("⌂","Home",0); addNavItem("♡","Stories",1); addNavItem("✉","Messages",2); addNavItem("⌕","Profiles",3); addNavItem("☰","Settings",4);
        root.addView(bottomNav); divider(root); setContentView(root);
    }
    private TextView icon(String s,int size) { TextView t=text(s,size,BLACK); t.setGravity(Gravity.CENTER); return t; }
    private void addNavItem(String glyph,String label,int which) {
        LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); TextView g=icon(glyph,26); TextView l=text(label,10,MUTED); l.setGravity(Gravity.CENTER); item.addView(g,new LinearLayout.LayoutParams(-1,dp(29))); item.addView(l); item.setPadding(0,dp(2),0,dp(2)); item.setOnClickListener(v->{ if(which==0)showHome(); else if(which==1)openPage("https://www.instagram.com/stories/","Stories"); else if(which==2)openPage(INBOX,"Messages"); else if(which==3)showProfiles(); else showSettings(); }); bottomNav.addView(item,new LinearLayout.LayoutParams(0,-2,1));
    }
    private void showHome() {
        if(webView.getParent()!=null)((android.view.ViewGroup)webView.getParent()).removeView(webView); webView.setVisibility(View.GONE); content.removeAllViews(); content.setVisibility(View.VISIBLE);
        LinearLayout top=row(); top.setPadding(dp(16),dp(9),dp(16),dp(9)); TextView storiesTitle=text("Stories",16,BLACK); storiesTitle.setTypeface(null,Typeface.BOLD); top.addView(storiesTitle,new LinearLayout.LayoutParams(0,-2,1)); TextView all=text("See all  ›",13,MUTED); top.addView(all); all.setOnClickListener(v->openPage("https://www.instagram.com/stories/","Stories")); content.addView(top);
        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); LinearLayout storyRow=row(); storyRow.setPadding(dp(10),dp(2),dp(10),dp(12));
        String[] names={"Your story","Close friends","Friends","Family","Classmates","Following"}; String[] glyph={"+","✦","A","M","R","S"};
        for(int i=0;i<names.length;i++){ final int idx=i; LinearLayout cell=new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER); cell.setPadding(dp(5),0,dp(5),0); TextView avatar=text(glyph[i],i==0?27:22, i==0?MUTED:WHITE); avatar.setGravity(Gravity.CENTER); avatar.setTypeface(null,Typeface.BOLD); avatar.setBackground(shape(i==0?SURFACE:new int[]{Color.rgb(190,55,150),Color.rgb(240,100,75),Color.rgb(245,180,60),Color.rgb(105,70,170),Color.rgb(60,150,180)}[i%5], i==0?LINE:Color.rgb(220,60,100), i==0?1:3,50)); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(62),dp(62)); ap.bottomMargin=dp(5); cell.addView(avatar,ap); TextView nm=text(names[i],11,BLACK); nm.setGravity(Gravity.CENTER); cell.addView(nm); cell.setOnClickListener(v->openPage("https://www.instagram.com/stories/","Stories")); storyRow.addView(cell,new LinearLayout.LayoutParams(dp(76),-2)); }
        hsv.addView(storyRow); content.addView(hsv); divider(content);
        LinearLayout welcome=new LinearLayout(this); welcome.setOrientation(LinearLayout.VERTICAL); welcome.setGravity(Gravity.CENTER); welcome.setPadding(dp(24),dp(28),dp(24),dp(28));
        TextView heading=text("Keep Instagram focused",21,BLACK); heading.setTypeface(null,Typeface.BOLD); heading.setGravity(Gravity.CENTER); welcome.addView(heading);
        TextView desc=text("Jump straight to the parts you came for.",14,MUTED); desc.setGravity(Gravity.CENTER); desc.setPadding(0,dp(7),0,dp(22)); welcome.addView(desc);
        addAction(welcome,"✉   Messages","Open your Instagram inbox",()->openPage(INBOX,"Messages")); addAction(welcome,"◉   Stories","View stories without a feed-first home",()->openPage("https://www.instagram.com/stories/","Stories")); addAction(welcome,"⌕   Find a profile","Search for a username",()->showProfiles());
        content.addView(welcome,new LinearLayout.LayoutParams(-1,-2));
    }
    private void addAction(LinearLayout parent,String title,String subtitle,Runnable action){ LinearLayout card=row(); card.setPadding(dp(14),dp(10),dp(12),dp(10)); card.setBackground(shape(SURFACE,LINE,1,12)); LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); TextView t=text(title,15,BLACK); t.setTypeface(null,Typeface.BOLD); words.addView(t); TextView s=text(subtitle,12,MUTED); s.setPadding(0,dp(3),0,0); words.addView(s); card.addView(words,new LinearLayout.LayoutParams(0,-2,1)); TextView arrow=text("›",26,BLACK); card.addView(arrow); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(16),dp(5),dp(16),dp(5)); parent.addView(card,lp); card.setOnClickListener(v->action.run()); }
    private void openPage(String url,String name){ content.removeAllViews(); content.setVisibility(View.VISIBLE); if(webView.getParent()!=null)((android.view.ViewGroup)webView.getParent()).removeView(webView); webView.setVisibility(View.VISIBLE); content.addView(webView,new LinearLayout.LayoutParams(-1,-1)); webView.loadUrl(url); }
    private void showProfiles(){ if(webView.getParent()!=null)((android.view.ViewGroup)webView.getParent()).removeView(webView); webView.setVisibility(View.GONE); content.setVisibility(View.VISIBLE); content.removeAllViews(); LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(18),dp(18),dp(18),dp(18)); TextView title=text("Find people",22,BLACK); title.setTypeface(null,Typeface.BOLD); panel.addView(title); TextView desc=text("Search by Instagram username",14,MUTED); desc.setPadding(0,dp(6),0,dp(14)); panel.addView(desc);
        EditText input=new EditText(this); input.setSingleLine(true); input.setTextColor(BLACK); input.setHintTextColor(MUTED); input.setHint("Username (without @)"); input.setImeOptions(EditorInfo.IME_ACTION_SEARCH); input.setPadding(dp(12),0,dp(12),0); input.setBackground(shape(INPUT,Color.TRANSPARENT,0,10)); panel.addView(input,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView go=text("View profile  →",15,WHITE); go.setGravity(Gravity.CENTER); go.setTypeface(null,Typeface.BOLD); go.setBackground(shape(Color.rgb(0,149,246),Color.TRANSPARENT,0,9)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(46)); gp.topMargin=dp(12); panel.addView(go,gp); Runnable open=()->{String u=input.getText().toString().trim().replace("@",""); if(!u.matches("[A-Za-z0-9._]{1,30}")){Toast.makeText(this,"Enter a valid username.",Toast.LENGTH_SHORT).show();return;} ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0); openPage("https://www.instagram.com/"+u+"/","Profile");}; go.setOnClickListener(v->open.run()); input.setOnEditorActionListener((v,a,e)->{if(a==EditorInfo.IME_ACTION_SEARCH){open.run();return true;}return false;}); content.addView(panel);
    }
    private java.util.ArrayList<String> savedAccounts() {
        String raw = accountPrefs.getString("usernames", "");
        java.util.ArrayList<String> result = new java.util.ArrayList<>();
        if (!raw.trim().isEmpty()) for (String name : raw.split("\\n")) if (!name.trim().isEmpty()) result.add(name.trim());
        return result;
    }
    private void persistAccounts(java.util.ArrayList<String> names) { StringBuilder b = new StringBuilder(); for (String n : names) { if (b.length() > 0) b.append('\n'); b.append(n); } accountPrefs.edit().putString("usernames", b.toString()).apply(); }
    private void showAccounts() {
        java.util.ArrayList<String> names = savedAccounts();
        java.util.ArrayList<String> choices = new java.util.ArrayList<>(names);
        choices.add("+ Add an account…");
        choices.add("Manage saved accounts");
        new AlertDialog.Builder(this).setTitle("Accounts").setItems(choices.toArray(new String[0]), (dialog, which) -> {
            if (which < names.size()) {
                String username = names.get(which);
                new AlertDialog.Builder(this).setTitle("@" + username).setMessage("Open this account's profile, or sign in/switch accounts on Instagram if the website offers that option.")
                    .setNegativeButton("Cancel", null).setNeutralButton("Remove", (d,w) -> { java.util.ArrayList<String> updated = savedAccounts(); updated.remove(username); persistAccounts(updated); Toast.makeText(this, "Removed @" + username, Toast.LENGTH_SHORT).show(); })
                    .setPositiveButton("Open profile", (d,w) -> openPage("https://www.instagram.com/" + username + "/", "Profile")).show();
            } else if (which == names.size()) addAccount();
            else manageAccounts();
        }).show();
    }
    private void addAccount() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setTextColor(BLACK); input.setHintTextColor(MUTED); input.setHint("Account username (without @)"); input.setPadding(dp(12),0,dp(12),0); input.setBackground(shape(INPUT,LINE,1,10));
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(20),dp(8),dp(20),0); wrap.addView(input,new LinearLayout.LayoutParams(-1,dp(48)));
        new AlertDialog.Builder(this).setTitle("Add account shortcut").setMessage("Save a username here, then sign in through Instagram's own login page. This app does not store passwords.").setView(wrap).setNegativeButton("Cancel",null).setPositiveButton("Continue to Instagram",(d,w)->{
            String username=input.getText().toString().trim().replace("@","");
            if (!username.matches("[A-Za-z0-9._]{1,30}")) { Toast.makeText(this,"Enter a valid username.",Toast.LENGTH_SHORT).show(); return; }
            java.util.ArrayList<String> names=savedAccounts(); if(!names.contains(username)){names.add(username);persistAccounts(names);} 
            openPage("https://www.instagram.com/accounts/login/?next=%2Fdirect%2Finbox%2F","Add account");
        }).show();
    }
    private void manageAccounts() {
        java.util.ArrayList<String> names=savedAccounts();
        if(names.isEmpty()){ new AlertDialog.Builder(this).setTitle("Saved accounts").setMessage("No account shortcuts yet.").setPositiveButton("Add account",(d,w)->addAccount()).setNegativeButton("Close",null).show(); return; }
        new AlertDialog.Builder(this).setTitle("Saved account shortcuts").setItems(names.toArray(new String[0]),(d,w)->new AlertDialog.Builder(this).setTitle("Remove @"+names.get(w)+"?").setPositiveButton("Remove",(a,b)->{java.util.ArrayList<String> updated=savedAccounts();updated.remove(names.get(w));persistAccounts(updated);}).setNegativeButton("Keep",null).show()).setPositiveButton("Add account",(d,w)->addAccount()).setNegativeButton("Done",null).show();
    }
    private void showSettings(){ String[] items={"Enable focus reminder (Accessibility)","Allow display over other apps","Return to Focus home"}; new AlertDialog.Builder(this).setTitle("Instagram Focus settings").setItems(items,(d,w)->{if(w==0){if(!Settings.canDrawOverlays(this))new AlertDialog.Builder(this).setTitle("Overlay permission needed").setMessage("Allow display over other apps first. The optional reminder detects only when Instagram is foregrounded; it does not read message text.").setNegativeButton("Cancel",null).setPositiveButton("Open permission",(a,b)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())))).show();else startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}else if(w==1)startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));else showHome();}).show(); }
    @Override public void onBackPressed(){if(webView.getVisibility()==View.VISIBLE&&webView.canGoBack())webView.goBack();else if(webView.getVisibility()==View.VISIBLE){webView.setVisibility(View.GONE);showHome();}else showHome();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.destroy();}super.onDestroy();}
}
