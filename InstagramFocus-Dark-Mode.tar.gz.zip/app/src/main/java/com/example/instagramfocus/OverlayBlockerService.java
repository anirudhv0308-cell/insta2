package com.example.instagramfocus;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayBlockerService extends Service {
    public static final String ACTION_SHOW = "com.example.instagramfocus.SHOW_BLOCKER";
    private WindowManager manager; private android.view.View overlay;
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent==null || !ACTION_SHOW.equals(intent.getAction()) || !Settings.canDrawOverlays(this) || overlay!=null) { stopSelf(); return START_NOT_STICKY; }
        manager=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setGravity(Gravity.CENTER); panel.setPadding(48,64,48,64); panel.setBackgroundColor(Color.rgb(249,249,252));
        TextView title=new TextView(this); title.setText("Pause — use Instagram Focus"); title.setTextColor(Color.rgb(35,35,42)); title.setTextSize(24); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); panel.addView(title);
        TextView desc=new TextView(this); desc.setText("The official Instagram app is outside your focused workspace. Open Messages, Stories or Profiles from Instagram Focus."); desc.setTextColor(Color.DKGRAY); desc.setTextSize(16); desc.setGravity(Gravity.CENTER); LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2); dp.topMargin=24; panel.addView(desc,dp);
        Button open=new Button(this); open.setText("Open Instagram Focus"); open.setAllCaps(false); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=28; panel.addView(open,bp);
        open.setOnClickListener(v->{ Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName()); if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(launch);} removeOverlay(); stopSelf(); });
        int type=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        // Focusable overlay intercepts taps while visible, instead of letting taps pass through to Instagram.
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,PixelFormat.TRANSLUCENT);
        try { manager.addView(panel,p); overlay=panel; } catch(Exception e){ stopSelf(); }
        return START_NOT_STICKY;
    }
    private void removeOverlay(){ if(overlay!=null && manager!=null){try{manager.removeView(overlay);}catch(Exception ignored){} overlay=null;} }
    @Override public void onDestroy(){removeOverlay();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
