package com.example.instagramfocus;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

public class FocusAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM_PACKAGE = "com.instagram.android";
    private long lastPrompt = 0;
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!INSTAGRAM_PACKAGE.equals(event.getPackageName().toString())) return;
        long now = System.currentTimeMillis(); if (now - lastPrompt < 2000) return; lastPrompt = now;
        try { Intent i = new Intent(this,OverlayBlockerService.class); i.setAction(OverlayBlockerService.ACTION_SHOW); startService(i); }
        catch (Exception ignored) {}
    }
    @Override public void onInterrupt() {}
}
